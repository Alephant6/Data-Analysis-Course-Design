提供的文档包括：
1，matlab示例：example_1生成正态分布的例
                           example_2散点矩阵图的例
2，sas示例：sas参考文档